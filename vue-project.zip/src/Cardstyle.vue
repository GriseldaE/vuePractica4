<template>
  <div class="card">
    <div class="card-header">
      <h2>Card</h2>
    </div>
    <div class="card-body">
      <p><strong>Nombre:</strong> {{ name }}</p>
      <p><strong>Edad:</strong> {{ age }}</p>
      <p><strong>Estado:</strong> {{ status }}</p>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    
    name: String,
    age: String,
    status: String,
  },
};
</script>

<style scoped>
.card {
  
  margin: 10px;
  padding: 10px;
  border: solid 2px black;
}

.card-header {
  background-color: purple;
  color:azure;
  padding: 1px;
  text-align: justify;
 
}
h2{
padding-left: 40px;
}

.card-body {
  padding: 1px;
}
</style>