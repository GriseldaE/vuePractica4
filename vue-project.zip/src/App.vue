<template>
  <div>
    <user-card
      
      name="Paco perez"
      age="27"
      status="Activo"
    ></user-card>

    <user-card
      
      name="Tomas Leyva"
      age="35"
      status="Inactivo"
    ></user-card>
  </div>
</template>

<script>
import UserCard from './Cardstyle.vue';

export default {
  components: {
    UserCard,
  },
};
</script>

